// Firebase console → Authentication → Sign-in method → Google → Web SDK configuration → "Web client ID".
// It looks like 1234567890-abcdef.apps.googleusercontent.com
export const GOOGLE_WEB_CLIENT_ID = 'PASTE_YOUR_WEB_CLIENT_ID_HERE';
